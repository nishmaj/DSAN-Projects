Problem 5  -- Blockchain

This implementation includes a class named Blockchain where "add_block" updates the current block.

The time complextity of add_block is O(1) 
Since the function occurs in constant time.

The space complexity of add_block is O(n) 
Since the function allocates a single variable every time so as the number of block increases space taken by program increases.