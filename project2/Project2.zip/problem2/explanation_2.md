Problem 2  -- Finding Files

For this problem, recursion is being used because it is not known how deep the file structure will go.

The time complexity of find_files() is O(n) 
Since n is the number of files in the directory

The space complexity of find_files() is O(n) 
Since a variable is allocated for the number of files in the directory


