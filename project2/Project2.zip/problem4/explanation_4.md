Problem 4 -- Active Directory

Recursion is being used so it is easier to search nested groups. Using the 'or' operator on the output so it only takes one call to report True for the output to be True.

The time complextity of is_user_in_group() is O(n) 
Since there are two for loops that are not nested.

The space complexity of is_user_in_group() is O(n) 
Since only one variable is allocated, as the cache capacity grows space complexity increases.